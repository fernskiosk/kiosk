﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoGo.NecroBot.CLI.WebSocketHandler.GetCommands.Helpers
{
    class EggListWeb
    {
        public object Incubators { get; set; }
        public object UnusedEggs { get; set; }

    }
}
