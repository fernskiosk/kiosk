﻿namespace PoGo.NecroBot.Logic.Event
{
    public class SnipeModeEvent : IEvent
    {
        public bool Active;
    }
}