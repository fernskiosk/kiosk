﻿namespace PoGo.NecroBot.Logic.Event
{
    public interface IEvent
    {
    }
}